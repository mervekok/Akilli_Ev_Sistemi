
package Akilli_Ev_Sistemi;

import Akilli_Ev_Sistemi.GirisSayfasi;
import VERİTABANI.Veritabanıbağlantısı;
import VERİTABANI.veriTabani;
import gnu.io.CommPortIdentifier;
import gnu.io.SerialPort;
import gnu.io.SerialPortEvent;
import gnu.io.SerialPortEventListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;


public class KullaniciPanel extends javax.swing.JFrame implements SerialPortEventListener {

    
    public static void setComPortName(String aComPortName) {
        comPortName = aComPortName;
    }
    
    String inputLine;
    String[] readArray = new String[100];
    SerialPort serialPort;
    int i = 0;
    private static String comPortName = "COM3";//BU BİLGİYİ FORM DAN DA ALABİLİRİZ

    public static String getComPortName() {
        return comPortName;
    }
    private static final String PORT_NAMES[] = {getComPortName(),};

    private BufferedReader input;
    private static OutputStream output;
    static int TIME_OUT = 2000;
    static int DATA_RATE = 57600;
    String date;
    public int baslangicKont=0;
    public int timerSayac=0;
    public int b;
    public void initialize() {
        
        System.setProperty("gnu.io.rxtx.SerialPorts", getComPortName());        
        CommPortIdentifier portId = null;        
        Enumeration portEnum = CommPortIdentifier.getPortIdentifiers();

        while (portEnum.hasMoreElements()) {
            CommPortIdentifier currPortId = (CommPortIdentifier) portEnum.nextElement();
            for (String portName : PORT_NAMES) {
                if (currPortId.getName().equals(portName)) {
                    System.out.println(portName);
                    portId = currPortId;
                    break;
                }
            }
        }
        if (portId == null) {
            
            JOptionPane.showMessageDialog(null," PORTUNA BAĞLI CİHAZ YOK!","HATA",JOptionPane.ERROR_MESSAGE);
            System.out.println("PORTA BAĞLI CİHAZ YOK!");
            return;
        }
System.out.println(portId);
        try {
            serialPort = (SerialPort) portId.open(this.getClass().getName(), TIME_OUT);

            serialPort.setSerialPortParams(DATA_RATE, SerialPort.DATABITS_8, SerialPort.STOPBITS_1,
                    SerialPort.PARITY_NONE);

            input = new BufferedReader(new InputStreamReader(serialPort.getInputStream()));
            output = serialPort.getOutputStream();

            serialPort.addEventListener(this);
            serialPort.notifyOnDataAvailable(true);
        } catch (Exception e) {
            System.err.println(e.toString());
        }
        SimpleDateFormat bicim=new SimpleDateFormat("yyyy-M-dd");
        
        
        date=(bicim.format(Calendar.getInstance().getTime()));
        cmbBox1.addItem(date);
    }
    public synchronized void close() {
        if (serialPort != null) {
            serialPort.removeEventListener();
            serialPort.close();
        }
    }
    VERİTABANI.veriTabani vt= new veriTabani();
    DefaultListModel model = new DefaultListModel();  
    public String[]parts;
    @Override
    public synchronized void serialEvent(SerialPortEvent oEvent) {

        if (oEvent.getEventType() == SerialPortEvent.DATA_AVAILABLE) {
            try {
                if (input.ready() == true) {
                  
                    inputLine = input.readLine();
                    
                     parts = inputLine.split(";");
                    
                    
                    Object node = inputLine;
                    model.addElement(node);
                    if(parts.length == 3) {
                        
                        vt.veriEkle(parts);
                        System.out.println("--------------------");
                        System.out.println("parts[0] : " + parts[0]);
                        System.out.println("parts[1] : " + parts[1]);
                        System.out.println("parts[2] : " + parts[2]);
                        progressBarGaz.setValue((int)  Double.parseDouble(parts[1]));
                        progressBarGaz.setString(parts[1]);
                        progressBarSicaklik.setValue((int)  Double.parseDouble(parts[2]));
                        progressBarSicaklik.setString(parts[2]);
                        
                      
                    list1.setModel(model);
                       
                    }
                    if(Integer.parseInt(parts[2])<22)
                    {
                        lbl3.setText("Sıcak Hava Fanları Aktif Edildi.");
                        otomatikDereceLbl.setText(parts[2]);
                    
                    }
                    if(Integer.parseInt(parts[2])>22){
                        lbl3.setText("Soğuk Hava Fanları Aktif Edildi.");
                        otomatikDereceLbl.setText(parts[2]);
                    
                    }
                   if(Integer.parseInt(parts[1])>250){
                        lbl4.setVisible(true);
                        lbl6.setVisible(false);
                        lbl5.setText("Kapılar Açıldı.");
                    }
                   else{
                        lbl6.setVisible(true);
                        lbl4.setVisible(false);
                   }
                   if(parts[0].equals("1"))
                   {
                        otomatikLedYanik.setVisible(true);
                        otomatikLedSonuk.setVisible(false);
                   }
                   if(parts[0].equals("0"))
                   {
                        otomatikLedYanik.setVisible(false);
                        otomatikLedSonuk.setVisible(true);
                   }  
                }
        }catch (Exception e) {
                System.err.println(e.toString());
            }
        }
    }
    Veritabanıbağlantısı vb = new Veritabanıbağlantısı();

    public Statement baglantiAc() throws SQLException, ClassNotFoundException, InstantiationException{
        try {
            Class.forName(vb.DRIVER).newInstance();
        vb.con = DriverManager.getConnection(vb.Url + vb.Db_name, vb.id,vb.ps);
        return vb.con.createStatement();
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Hata Olustu"+e);
        }
    throw new UnsupportedOperationException("Bir hata oluştu..");
    }
    public void baglantiKapat() throws  SQLException{
        vb.con.close();
    }

     public void tabloVeriDoldur()
    {
        try {
            Statement s = baglantiAc();
            String sql;
            sql = "select val,analogSensor,sicaklik,kayit_tarihi from akilli_ev_sistemi.veriler where kayit_tarihi like '%"+cmbBox1.getSelectedItem()+"%'";
                       ResultSet rs = s.executeQuery(sql);
            TabloModeliOlustur model = new TabloModeliOlustur(rs);
            tablo.setModel(model);
            baglantiKapat();
        } catch (SQLException | ClassNotFoundException | InstantiationException e) {
            JOptionPane.showMessageDialog(null, "Sicil No Giriniz!!!");
        }
    }
     
    public void tarihGetir(){
        cmbBox1.removeAllItems();
        veriTabani vt= new veriTabani();
        ArrayList<veriTabani> liste2 = new ArrayList<veriTabani>();
       try{
        liste2=vt.tarihGetir();
        
       }catch(Exception e){}
     
         for (int j = 0; j < liste2.size(); j++) {
             cmbBox1.addItem(liste2.get(j).getTarih());
         }
    }

    
 public KullaniciPanel() {
        initComponents();
        this.setLocationRelativeTo(null);
        PortListele();
        lbl4.setVisible(false);
        lbl6.setVisible(false);
        tarihGetir();
        Panel2.setVisible(false);
        dereceLbl.setVisible(false);
        santiLbl.setVisible(false);
        arttirBtn.setVisible(false);
        azaltBtn.setVisible(false);
        otomatikDereceLbl.setVisible(false);
        sogutBtn.setVisible(false);
        sicakBtn.setVisible(false);
        manuelSayfa.setVisible(false);
        otomatikSayfa.setVisible(false);
        otomatikLedSonuk.setVisible(false);
        otomatikLedYanik.setVisible(false);
        manuelLedIYanik.setVisible(false);
        ManuelLedSonuk.setVisible(false);
        Panel3.setVisible(false);
    }
  

   public void PortListele(){
       this.setLocationRelativeTo(null);
 
    }
  

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        Panel1 = new javax.swing.JPanel();
        progressBarSicaklik = new javax.swing.JProgressBar();
        jTextField3 = new javax.swing.JTextField();
        cmbBox1 = new javax.swing.JComboBox<String>();
        jScrollPane2 = new javax.swing.JScrollPane();
        list1 = new javax.swing.JList();
        btn = new javax.swing.JButton();
        progressBarGaz = new javax.swing.JProgressBar();
        jScrollPane3 = new javax.swing.JScrollPane();
        tablo = new javax.swing.JTable();
        btn2 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        cikisYapBtn = new javax.swing.JButton();
        lbl3 = new javax.swing.JLabel();
        lbl6 = new javax.swing.JLabel();
        lbl4 = new javax.swing.JLabel();
        lbl5 = new javax.swing.JLabel();
        manuelSistemBtn = new javax.swing.JButton();
        geriDönBtn = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        Panel2 = new javax.swing.JPanel();
        Panel3 = new javax.swing.JPanel();
        ManuelBtn = new javax.swing.JButton();
        otomatikBtn = new javax.swing.JButton();
        arttirBtn = new javax.swing.JButton();
        azaltBtn = new javax.swing.JButton();
        sicakBtn = new javax.swing.JButton();
        sogutBtn = new javax.swing.JButton();
        ayarlaBtn = new javax.swing.JButton();
        kapatBtn = new javax.swing.JButton();
        Panel4 = new javax.swing.JPanel();
        dereceLbl = new javax.swing.JLabel();
        santiLbl = new javax.swing.JLabel();
        funLbl = new javax.swing.JLabel();
        otomatikDereceLbl = new javax.swing.JLabel();
        geriBtn = new javax.swing.JButton();
        İsikKontrolPanel = new javax.swing.JPanel();
        otomatikLedBtn = new javax.swing.JButton();
        manuelSayfa = new javax.swing.JPanel();
        ledYak = new javax.swing.JButton();
        ledSondur = new javax.swing.JButton();
        ManuelLedSonuk = new javax.swing.JLabel();
        manuelLedIYanik = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        otomatikSayfa = new javax.swing.JPanel();
        otomatikLedYanik = new javax.swing.JLabel();
        otomatikLedSonuk = new javax.swing.JLabel();
        manuelLedBtn = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        jLabel1.setText("jLabel1");

        jButton4.setText("jButton4");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Panel1.setPreferredSize(new java.awt.Dimension(1272, 485));
        Panel1.setLayout(null);

        progressBarSicaklik.setMinimum(-40);
        progressBarSicaklik.setDoubleBuffered(true);
        progressBarSicaklik.setStringPainted(true);
        Panel1.add(progressBarSicaklik);
        progressBarSicaklik.setBounds(140, 60, 120, 19);

        jTextField3.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jTextField3.setText("Alınan Günlük Değerler");
        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });
        Panel1.add(jTextField3);
        jTextField3.setBounds(373, 62, 160, 22);

        cmbBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbBox1ActionPerformed(evt);
            }
        });
        Panel1.add(cmbBox1);
        cmbBox1.setBounds(553, 62, 177, 22);

        list1.setMaximumSize(new java.awt.Dimension(0, 1000));
        jScrollPane2.setViewportView(list1);

        Panel1.add(jScrollPane2);
        jScrollPane2.setBounds(12, 122, 153, 272);

        btn.setText("Başlat");
        btn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204), 2));
        btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActionPerformed(evt);
            }
        });
        Panel1.add(btn);
        btn.setBounds(97, 411, 90, 30);

        progressBarGaz.setMaximum(1000);
        progressBarGaz.setMinimum(-40);
        progressBarGaz.setDoubleBuffered(true);
        progressBarGaz.setStringPainted(true);
        Panel1.add(progressBarGaz);
        progressBarGaz.setBounds(140, 20, 120, 19);

        tablo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane3.setViewportView(tablo);

        Panel1.add(jScrollPane3);
        jScrollPane3.setBounds(177, 127, 651, 267);

        btn2.setText("Günlük Veri Çek");
        btn2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204), 2));
        btn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn2ActionPerformed(evt);
            }
        });
        Panel1.add(btn2);
        btn2.setBounds(430, 411, 150, 30);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/akilli-evler-nedir-akilli-ev-otomasyonlari2-446x435.jpg"))); // NOI18N
        jLabel2.setToolTipText("");
        jLabel2.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jLabel2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel2.setIconTextGap(0);
        jLabel2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        Panel1.add(jLabel2);
        jLabel2.setBounds(840, 60, 330, 300);

        cikisYapBtn.setText("Çıkış Yap");
        cikisYapBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204), 2));
        cikisYapBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cikisYapBtnActionPerformed(evt);
            }
        });
        Panel1.add(cikisYapBtn);
        cikisYapBtn.setBounds(1090, 520, 70, 40);

        lbl3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lbl3.setForeground(new java.awt.Color(0, 0, 153));
        Panel1.add(lbl3);
        lbl3.setBounds(1325, 0, 330, 28);

        lbl6.setForeground(new java.awt.Color(0, 204, 0));
        lbl6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/depositphotos_117111088-stock-illustration-closed-wooden-door-icon-simple.jpg"))); // NOI18N
        lbl6.setText("HERŞEY KONTROL ALTINDA");
        Panel1.add(lbl6);
        lbl6.setBounds(610, 410, 212, 50);

        lbl4.setForeground(new java.awt.Color(255, 0, 0));
        lbl4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/criminal-forcing-a-door_318-56169.jpg"))); // NOI18N
        lbl4.setText("ACİL DURUM");
        Panel1.add(lbl4);
        lbl4.setBounds(850, 410, 134, 50);

        lbl5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lbl5.setForeground(new java.awt.Color(0, 0, 102));
        lbl5.setPreferredSize(new java.awt.Dimension(100, 50));
        Panel1.add(lbl5);
        lbl5.setBounds(650, 490, 210, 30);

        manuelSistemBtn.setText("Manuel Sistem Kontrol");
        manuelSistemBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204), 2));
        manuelSistemBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                manuelSistemBtnActionPerformed(evt);
            }
        });
        Panel1.add(manuelSistemBtn);
        manuelSistemBtn.setBounds(220, 411, 180, 30);

        geriDönBtn.setText("Geri Dön");
        geriDönBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204), 2));
        geriDönBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                geriDönBtnActionPerformed(evt);
            }
        });
        Panel1.add(geriDönBtn);
        geriDönBtn.setBounds(10, 530, 80, 30);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jLabel3.setText("Gaz :");
        Panel1.add(jLabel3);
        jLabel3.setBounds(40, 20, 50, 20);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jLabel4.setText("Oda Sıcaklığı:");
        Panel1.add(jLabel4);
        jLabel4.setBounds(40, 60, 90, 20);

        Panel2.setMaximumSize(new java.awt.Dimension(500, 500));
        Panel2.setLayout(null);

        Panel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Panel3.setLayout(null);

        ManuelBtn.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        ManuelBtn.setText(" Manuel");
        ManuelBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ManuelBtnActionPerformed(evt);
            }
        });
        Panel3.add(ManuelBtn);
        ManuelBtn.setBounds(20, 340, 88, 23);

        otomatikBtn.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        otomatikBtn.setText("Otomatik ");
        otomatikBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                otomatikBtnActionPerformed(evt);
            }
        });
        Panel3.add(otomatikBtn);
        otomatikBtn.setBounds(140, 340, 93, 23);

        arttirBtn.setBackground(new java.awt.Color(204, 204, 204));
        arttirBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/images (1).jpg"))); // NOI18N
        arttirBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                arttirBtnActionPerformed(evt);
            }
        });
        Panel3.add(arttirBtn);
        arttirBtn.setBounds(100, 190, 40, 40);

        azaltBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/images (2).jpg"))); // NOI18N
        azaltBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                azaltBtnActionPerformed(evt);
            }
        });
        Panel3.add(azaltBtn);
        azaltBtn.setBounds(110, 280, 30, 30);

        sicakBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/temperature-icon-png-11094.png"))); // NOI18N
        sicakBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sicakBtnActionPerformed(evt);
            }
        });
        Panel3.add(sicakBtn);
        sicakBtn.setBounds(20, 220, 41, 35);

        sogutBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Coloured_Weather_Icon_Set_by_ViconsDesign-13-512.png"))); // NOI18N
        sogutBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sogutBtnActionPerformed(evt);
            }
        });
        Panel3.add(sogutBtn);
        sogutBtn.setBounds(190, 220, 40, 32);

        ayarlaBtn.setFont(new java.awt.Font("Arial Black", 1, 13)); // NOI18N
        ayarlaBtn.setText("Ayarla");
        ayarlaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ayarlaBtnActionPerformed(evt);
            }
        });
        Panel3.add(ayarlaBtn);
        ayarlaBtn.setBounds(80, 240, 90, 30);

        kapatBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/Close.png"))); // NOI18N
        kapatBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kapatBtnActionPerformed(evt);
            }
        });
        Panel3.add(kapatBtn);
        kapatBtn.setBounds(110, 410, 23, 24);

        Panel4.setBackground(new java.awt.Color(255, 255, 255));
        Panel4.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 204), 5, true));
        Panel4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Panel4.setLayout(null);

        dereceLbl.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        dereceLbl.setText("23");
        Panel4.add(dereceLbl);
        dereceLbl.setBounds(30, 50, 70, 50);

        santiLbl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/indir_1.jpg"))); // NOI18N
        Panel4.add(santiLbl);
        santiLbl.setBounds(100, 10, 105, 100);

        funLbl.setFont(new java.awt.Font("Arial Black", 1, 13)); // NOI18N
        Panel4.add(funLbl);
        funLbl.setBounds(10, 110, 210, 32);

        otomatikDereceLbl.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        Panel4.add(otomatikDereceLbl);
        otomatikDereceLbl.setBounds(29, 49, 70, 50);

        Panel3.add(Panel4);
        Panel4.setBounds(10, 10, 230, 160);

        Panel2.add(Panel3);
        Panel3.setBounds(88, 26, 254, 500);

        geriBtn.setText("Geri");
        geriBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        geriBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                geriBtnActionPerformed(evt);
            }
        });
        Panel2.add(geriBtn);
        geriBtn.setBounds(12, 556, 50, 20);

        İsikKontrolPanel.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 20, true));
        İsikKontrolPanel.setLayout(null);

        otomatikLedBtn.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        otomatikLedBtn.setText("Otomatik Ayarla");
        otomatikLedBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                otomatikLedBtnActionPerformed(evt);
            }
        });
        İsikKontrolPanel.add(otomatikLedBtn);
        otomatikLedBtn.setBounds(180, 250, 140, 23);

        ledYak.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        ledYak.setForeground(new java.awt.Color(0, 51, 204));
        ledYak.setText("Işık Yak");
        ledYak.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ledYakActionPerformed(evt);
            }
        });

        ledSondur.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        ledSondur.setForeground(new java.awt.Color(0, 51, 204));
        ledSondur.setText("Işık Söndür");
        ledSondur.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ledSondurActionPerformed(evt);
            }
        });

        ManuelLedSonuk.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/gluhbirne-umriss_318-50403.jpg"))); // NOI18N

        manuelLedIYanik.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/cubical-smarthomes-ambient-lighting.png"))); // NOI18N

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jButton2.setText("Onayla");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout manuelSayfaLayout = new javax.swing.GroupLayout(manuelSayfa);
        manuelSayfa.setLayout(manuelSayfaLayout);
        manuelSayfaLayout.setHorizontalGroup(
            manuelSayfaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, manuelSayfaLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(manuelLedIYanik, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ManuelLedSonuk)
                .addGap(26, 26, 26))
            .addGroup(manuelSayfaLayout.createSequentialGroup()
                .addGroup(manuelSayfaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(manuelSayfaLayout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(ledYak))
                    .addGroup(manuelSayfaLayout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(manuelSayfaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(manuelSayfaLayout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jButton2))
                            .addComponent(ledSondur))))
                .addContainerGap(30, Short.MAX_VALUE))
        );
        manuelSayfaLayout.setVerticalGroup(
            manuelSayfaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, manuelSayfaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(manuelSayfaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(manuelLedIYanik, javax.swing.GroupLayout.DEFAULT_SIZE, 56, Short.MAX_VALUE)
                    .addComponent(ManuelLedSonuk, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(ledYak)
                .addGap(18, 18, 18)
                .addComponent(ledSondur)
                .addGap(10, 10, 10)
                .addComponent(jButton2))
        );

        İsikKontrolPanel.add(manuelSayfa);
        manuelSayfa.setBounds(20, 20, 160, 190);

        otomatikLedYanik.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/cubical-smarthomes-ambient-lighting.png"))); // NOI18N

        otomatikLedSonuk.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/gluhbirne-umriss_318-50403.jpg"))); // NOI18N

        javax.swing.GroupLayout otomatikSayfaLayout = new javax.swing.GroupLayout(otomatikSayfa);
        otomatikSayfa.setLayout(otomatikSayfaLayout);
        otomatikSayfaLayout.setHorizontalGroup(
            otomatikSayfaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(otomatikSayfaLayout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addGroup(otomatikSayfaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(otomatikLedYanik, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(otomatikLedSonuk, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(63, Short.MAX_VALUE))
        );
        otomatikSayfaLayout.setVerticalGroup(
            otomatikSayfaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(otomatikSayfaLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(otomatikLedYanik)
                .addGap(18, 18, 18)
                .addComponent(otomatikLedSonuk, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(47, Short.MAX_VALUE))
        );

        İsikKontrolPanel.add(otomatikSayfa);
        otomatikSayfa.setBounds(180, 20, 160, 190);

        manuelLedBtn.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        manuelLedBtn.setText("Manuel Ayarla");
        manuelLedBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                manuelLedBtnActionPerformed(evt);
            }
        });
        İsikKontrolPanel.add(manuelLedBtn);
        manuelLedBtn.setBounds(30, 250, 120, 23);

        Panel2.add(İsikKontrolPanel);
        İsikKontrolPanel.setBounds(401, 133, 361, 341);

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jButton1.setText("Kumanda");
        jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        Panel2.add(jButton1);
        jButton1.setBounds(180, 550, 80, 30);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Panel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1180, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(layout.createSequentialGroup()
                .addGap(145, 145, 145)
                .addComponent(Panel2, javax.swing.GroupLayout.PREFERRED_SIZE, 866, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Panel1, javax.swing.GroupLayout.PREFERRED_SIZE, 570, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Panel2, javax.swing.GroupLayout.PREFERRED_SIZE, 599, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        getAccessibleContext().setAccessibleDescription("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void geriDönBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_geriDönBtnActionPerformed
        
        new GirisSayfasi().setVisible(true);
        this.dispose();
        
    }//GEN-LAST:event_geriDönBtnActionPerformed

    private void cikisYapBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cikisYapBtnActionPerformed
        System.exit(0);
    }//GEN-LAST:event_cikisYapBtnActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void cmbBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbBox1ActionPerformed
        
    }//GEN-LAST:event_cmbBox1ActionPerformed

    private void btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActionPerformed
        baslangicKont=1;
        setComPortName("COM3");
        DATA_RATE = 57600;
        TIME_OUT = 2000;
        initialize();
        //txtReadData.setText(txtComPortName.getText()+" PORT AÇILDI\n");
       // txtReadData.setText(txtReadData.getText() + "Veri Bekleniyor...\n");
        model.clear();
    }//GEN-LAST:event_btnActionPerformed

    private void btn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn2ActionPerformed
        tabloVeriDoldur();
    }//GEN-LAST:event_btn2ActionPerformed

    private void manuelSistemBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_manuelSistemBtnActionPerformed
        if(baslangicKont==0)
        {
            JOptionPane.showMessageDialog(null, "Sistem ile Bağlatıyı Başlatınız..");
        }
        else{
        Panel1.setVisible(false);
        Panel2.setVisible(true);
        }
    }//GEN-LAST:event_manuelSistemBtnActionPerformed

    private void sogutBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sogutBtnActionPerformed
            try {
                        String serialMessage = "6";
                        output.write(serialMessage.getBytes());
                    } catch (IOException ex) {

                       }
    }//GEN-LAST:event_sogutBtnActionPerformed

    private void otomatikBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_otomatikBtnActionPerformed
        dereceLbl.setVisible(false);
        otomatikDereceLbl.setVisible(true);
        santiLbl.setVisible(true);
        arttirBtn.setVisible(false);
        azaltBtn.setVisible(false);
        
        
                {if(Integer.parseInt(parts[2])<22)
                    {
                    dereceLbl.setText("25");
                    funLbl.setText("Isıtıcı Fanlar Aktif");
                    try {
                        String serialMessage = "1";
                        output.write(serialMessage.getBytes());
                    } catch (IOException ex) {

                       }
                    }
          if(Integer.parseInt(parts[2])>22){
                    dereceLbl.setText("20");
                    funLbl.setText("Soğutucu Fanlar Aktif");
                    try {
                        String serialMessage = "2";
                        output.write(serialMessage.getBytes());
                    } catch (IOException ex) {

                       }
          }       
           }
    }//GEN-LAST:event_otomatikBtnActionPerformed
int sayacKontrol;
    private void ManuelBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ManuelBtnActionPerformed
        dereceLbl.setVisible(true);
        santiLbl.setVisible(true);
        arttirBtn.setVisible(true);
        azaltBtn.setVisible(true);
        sogutBtn.setVisible(true);
        sicakBtn.setVisible(true);
        otomatikDereceLbl.setVisible(false);
        sayacKontrol=0;
        
        dereceLbl.setText(parts[2]);
    }//GEN-LAST:event_ManuelBtnActionPerformed

    private void sicakBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sicakBtnActionPerformed
        try {
                        String serialMessage = "7";
                        output.write(serialMessage.getBytes());
                    } catch (IOException ex) {

                       }
    }//GEN-LAST:event_sicakBtnActionPerformed

    private void ayarlaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ayarlaBtnActionPerformed
                try {
                        //derece arttirma
                        String serialMessage = "5";
                        output.write(serialMessage.getBytes());
                    } catch (IOException ex) {
                       }
        
    }//GEN-LAST:event_ayarlaBtnActionPerformed

    private void geriBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_geriBtnActionPerformed
       new KullaniciPanel().setVisible(true);
       this.dispose();
    }//GEN-LAST:event_geriBtnActionPerformed
    String a;
    int sayacArttirma=0;
    private void arttirBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_arttirBtnActionPerformed
        dereceLbl.getText();
       b= Integer.parseInt(dereceLbl.getText());
       b++;
        a=String.valueOf(b);
        sayacArttirma++;
                       try {
                        //derece arttirma
                        String serialMessage = "3";
                        output.write(serialMessage.getBytes());
                    } catch (IOException ex) {
                       }
        dereceLbl.setText(a);
    }//GEN-LAST:event_arttirBtnActionPerformed

    private void kapatBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kapatBtnActionPerformed
      Panel3.setVisible(false);
    }//GEN-LAST:event_kapatBtnActionPerformed

    private void azaltBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_azaltBtnActionPerformed
         dereceLbl.getText();
       b= Integer.parseInt(dereceLbl.getText());
       b--;
       String a=String.valueOf(b);
        try {
                        //derece azaltma
                        String serialMessage = "4";
                        output.write(serialMessage.getBytes());
                    } catch (IOException ex) {

                       }
       
        dereceLbl.setText(a);
    }//GEN-LAST:event_azaltBtnActionPerformed

    private void otomatikLedBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_otomatikLedBtnActionPerformed
       otomatikSayfa.setVisible(true);
       manuelSayfa.setVisible(false);
       otomatikLedYanik.setVisible(true);
       otomatikLedSonuk.setVisible(true);
        if(btnKontrol==1){
            try { 
                        String serialMessage = "11";
                        output.write(serialMessage.getBytes());
                    } catch (IOException ex) {
                    }             
        }else{
        JOptionPane.showMessageDialog(null, "Sistem Zaten Otomatik İstersen Manuele alabilirsin");
                }
        btnKontrol=0;
    }//GEN-LAST:event_otomatikLedBtnActionPerformed

    private void ledYakActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ledYakActionPerformed
       manuelLedIYanik.setVisible(true);
       ManuelLedSonuk.setVisible(false);
        try { 
                        String serialMessage = "9";
                        output.write(serialMessage.getBytes());
                    } catch (IOException ex) {
                       }
    }//GEN-LAST:event_ledYakActionPerformed
int btnKontrol=0;
    private void manuelLedBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_manuelLedBtnActionPerformed
       manuelSayfa.setVisible(true);
       otomatikSayfa.setVisible(false);
       if(btnKontrol==0){
                    try { 
                        String serialMessage = "8";
                        output.write(serialMessage.getBytes());
                    } catch (IOException ex) {
                       }
       }
       btnKontrol=1;
    }//GEN-LAST:event_manuelLedBtnActionPerformed

    private void ledSondurActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ledSondurActionPerformed
                 manuelLedIYanik.setVisible(false);
                  ManuelLedSonuk.setVisible(true);
                    try { 
                        String serialMessage = "10";
                        output.write(serialMessage.getBytes());
                    } catch (IOException ex) {
                       }
    }//GEN-LAST:event_ledSondurActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Panel3.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        try { 
                        String serialMessage = "12";
                        output.write(serialMessage.getBytes());
                    } catch (IOException ex) {
                       }
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(KullaniciPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(KullaniciPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(KullaniciPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(KullaniciPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new KullaniciPanel().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ManuelBtn;
    private javax.swing.JLabel ManuelLedSonuk;
    private javax.swing.JPanel Panel1;
    private javax.swing.JPanel Panel2;
    private javax.swing.JPanel Panel3;
    private javax.swing.JPanel Panel4;
    private javax.swing.JButton arttirBtn;
    private javax.swing.JButton ayarlaBtn;
    private javax.swing.JButton azaltBtn;
    private javax.swing.JButton btn;
    private javax.swing.JButton btn2;
    private javax.swing.JButton cikisYapBtn;
    private javax.swing.JComboBox<String> cmbBox1;
    private javax.swing.JLabel dereceLbl;
    private javax.swing.JLabel funLbl;
    private javax.swing.JButton geriBtn;
    private javax.swing.JButton geriDönBtn;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JButton kapatBtn;
    private javax.swing.JLabel lbl3;
    private javax.swing.JLabel lbl4;
    private javax.swing.JLabel lbl5;
    private javax.swing.JLabel lbl6;
    private javax.swing.JButton ledSondur;
    private javax.swing.JButton ledYak;
    private javax.swing.JList list1;
    private javax.swing.JButton manuelLedBtn;
    private javax.swing.JLabel manuelLedIYanik;
    private javax.swing.JPanel manuelSayfa;
    private javax.swing.JButton manuelSistemBtn;
    private javax.swing.JButton otomatikBtn;
    private javax.swing.JLabel otomatikDereceLbl;
    private javax.swing.JButton otomatikLedBtn;
    private javax.swing.JLabel otomatikLedSonuk;
    private javax.swing.JLabel otomatikLedYanik;
    private javax.swing.JPanel otomatikSayfa;
    private javax.swing.JProgressBar progressBarGaz;
    private javax.swing.JProgressBar progressBarSicaklik;
    private javax.swing.JLabel santiLbl;
    private javax.swing.JButton sicakBtn;
    private javax.swing.JButton sogutBtn;
    private javax.swing.JTable tablo;
    private javax.swing.JPanel İsikKontrolPanel;
    // End of variables declaration//GEN-END:variables

 
    
}
