
package Akilli_Ev_Sistemi;

import Akilli_Ev_Sistemi.KullaniciPanel;

import VERİTABANI.GirisYap;
import VERİTABANI.GirisYap2;
import VERİTABANI.Veritabanıbağlantısı;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public final class GirisSayfasi extends javax.swing.JFrame {

    
    public GirisSayfasi() {
        initComponents();
        this.setLocationRelativeTo(null);
        kullaniciKayitDuzenleme();
    }
    Veritabanıbağlantısı vb = new Veritabanıbağlantısı();
    public Statement baglantiAc() throws SQLException{
    
        try {
            Class.forName(vb.DRIVER).newInstance();
            vb.con = DriverManager.getConnection(vb.Url+vb.Db_name,vb.id,vb.ps);
        }
            
         catch (ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException e) {
    JOptionPane.showMessageDialog(null, "Bağlantı Başarısız"+e);
        }
        return vb.con.createStatement();
    }
    public void baglantiKapat() throws SQLException{
    
    vb.con.close();
    }
public void kullaniciKayitDuzenleme(){
    
        try {
            Statement st = baglantiAc();
            String sql="Select kul_no from kullanici order by kul_no desc limit 1";
            
            ResultSet rs =st.executeQuery(sql);
            String kulNo="";
            while (rs.next()) {     
                kulNo=rs.getString("kul_no");
            }
            baglantiKapat();
            kulNo =Integer.toString(Integer.parseInt(kulNo)+1);
            kulNoLbl.setText(kulNo);
        } catch (SQLException | NumberFormatException e) {
            
            JOptionPane.showMessageDialog(null,"Kullanıcı Numarası oluşturulurken hata oluştu" +e);
        }
    
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        cikisYapBtn = new javax.swing.JButton();
        alinanAdTf = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        alinanSifreTf = new javax.swing.JPasswordField();
        KulGirisBtn = new javax.swing.JButton();
        bilgiLbl = new javax.swing.JLabel();
        kulNoLbl = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();

        jButton1.setText("jButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        cikisYapBtn.setText("Çıkış Yap");
        cikisYapBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cikisYapBtnActionPerformed(evt);
            }
        });

        alinanAdTf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alinanAdTfActionPerformed(evt);
            }
        });

        jLabel1.setText("Kullanıcı Adı :");

        jLabel2.setText("Şifre :");

        alinanSifreTf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alinanSifreTfActionPerformed(evt);
            }
        });

        KulGirisBtn.setText("Kullanıcı Girişi");
        KulGirisBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KulGirisBtnActionPerformed(evt);
            }
        });

        bilgiLbl.setText("Kullanıcı Adı ve Şifre giriniz");

        kulNoLbl.setText("null");

        jButton2.setText("Admin Giriş");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jLabel4.setText("Kayıtlı Kullanıcı Sayısı");

        jLabel5.setText("Eve");

        jLabel6.setText("Giriş");

        jLabel7.setText("için");

        jLabel8.setForeground(new java.awt.Color(255, 51, 51));
        jLabel8.setText("Kullanıcı Adı");
        jLabel8.setAutoscrolls(true);

        jLabel9.setText("ve ");

        jLabel3.setForeground(new java.awt.Color(255, 102, 102));
        jLabel3.setText("Şifre");

        jLabel10.setText("Giriniz.");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(KulGirisBtn)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel4))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(bilgiLbl)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel1))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(alinanAdTf, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                                            .addComponent(alinanSifreTf))))
                                .addGap(0, 92, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(kulNoLbl)
                        .addGap(26, 26, 26))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9)
                .addGap(12, 12, 12)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10)
                .addGap(0, 117, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(141, 141, 141)
                .addComponent(cikisYapBtn)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addComponent(jLabel3)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(alinanAdTf, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(alinanSifreTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bilgiLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(kulNoLbl)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(KulGirisBtn)
                    .addComponent(jButton2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cikisYapBtn)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        jPanel1.getAccessibleContext().setAccessibleDescription("");

        getAccessibleContext().setAccessibleDescription("Giriş Paneli");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void alinanSifreTfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alinanSifreTfActionPerformed
   
    }//GEN-LAST:event_alinanSifreTfActionPerformed

    private void cikisYapBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cikisYapBtnActionPerformed
        dispose();
    }//GEN-LAST:event_cikisYapBtnActionPerformed
     public boolean kullaniciMi;
    public int kullaniciYanlisSayac=3;
    private void KulGirisBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KulGirisBtnActionPerformed
         try {
            GirisYap gy =new GirisYap();
            kullaniciMi=gy.girisYap2(alinanAdTf.getText(), alinanSifreTf.getText());
            if (kullaniciMi) {
                new KullaniciPanel().setVisible(true);
                this.dispose();
                
            }else{
                kullaniciYanlisSayac--;
                if(kullaniciYanlisSayac != 0)
                    System.out.println(kullaniciYanlisSayac +"hakkınız kaldı");
                else
                    System.out.println("Sistem Kitlendi Çıkış Yapın");
                if(kullaniciYanlisSayac == 0){
                    this.KulGirisBtn.setVisible(false);
                }
                
            }
  
         } catch (Exception e) {
           JOptionPane.showMessageDialog(null,"Kullanıcı Adı ve Şifre Hatalı!");     
        }
    }//GEN-LAST:event_KulGirisBtnActionPerformed

    private void alinanAdTfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alinanAdTfActionPerformed
        
    }//GEN-LAST:event_alinanAdTfActionPerformed
    public boolean adminMi;
    public int adminYanlisSayac=3;
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        
        try {
            GirisYap2 gy1 =new GirisYap2();
            adminMi=gy1.girisYap(alinanAdTf.getText(), alinanSifreTf.getText());
            if (adminMi) {
                new AdminPanel().setVisible(true);
                this.dispose();
                
            }else{
                adminYanlisSayac--;
                if(adminYanlisSayac != 0)
                    System.out.println(adminYanlisSayac +" hakkınız kaldı");
                else
                    System.out.println("Sistem Kitlendi Çıkış Yapın");
                if(adminYanlisSayac == 0){
                    this.jButton2.setVisible(false);
                }
                
            }
            
            
            
            /*if(adminMi==false){
                while(adminMi==true){
                    
                    System.out.println(gy1.girisSayisi2);
                    bilgiLbl.setText("Yanlış Şifre");
                    gy1.girisYap(alinanAdTf.getText(), alinanSifreTf.getText());
                
                }
            }*/
            
         } catch (Exception e) {
            
            JOptionPane.showMessageDialog(null,"Kullanıcı Adı ve Şifre Hatalı!");
              
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GirisSayfasi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton KulGirisBtn;
    private javax.swing.JTextField alinanAdTf;
    private javax.swing.JPasswordField alinanSifreTf;
    private javax.swing.JLabel bilgiLbl;
    private javax.swing.JButton cikisYapBtn;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel kulNoLbl;
    // End of variables declaration//GEN-END:variables

    
}
