/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VERİTABANI;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Ersn
 */
public class veriTabani {
   
    private String val;
    private String analogSensor;
    private String sicaklik;
    private String KullaniciAdi;
    private String KullaniciSifre;

    public String getTarih() {
        return Tarih;
    }

    public void setTarih(String Tarih) {
        this.Tarih = Tarih;
    }
    private String Tarih;

    public String getKullaniciAdi() {
        return KullaniciAdi;
    }

    public void setKullaniciAdi(String KullaniciAdi) {
        this.KullaniciAdi = KullaniciAdi;
    }

    public String getKullaniciSifre() {
        return KullaniciSifre;
    }

    public void setKullaniciSifre(String KullaniciSifre) {
        this.KullaniciSifre = KullaniciSifre;
    }
    public String getVal() {
        return val;
    }

    public void setVal(String val) {
        this.val = val;
    }

    public String getAnalogSensor() {
        return analogSensor;
    }

    public void setAnalogSensor(String analogSensor) {
        this.analogSensor = analogSensor;
    }

    public String getSicaklik() {
        return sicaklik;
    }

    public void setSicaklik(String sicaklik) {
        this.sicaklik = sicaklik;
    }


     public void veriEkle(String dizi[])throws SQLException{
        try
        {
            //JOptionPane.showMessageDialog(null, dizi[0]);
            Veritabanıbağlantısı vb=new Veritabanıbağlantısı();
            vb.baglan();  
            //JOptionPane.showMessageDialog(null, "Burdasdın.");
            //ResultSet rs;  //butoon işlemini yaptı
            String sorgu="insert into veriler(val, analogSensor, sicaklik, kayit_tarihi) values (?,?,?,NOW());";
            
            PreparedStatement ps= vb.con.prepareStatement(sorgu);
            
            ps.setString(1, dizi[0]);
            ps.setString(2, dizi[1]);
            ps.setString(3, dizi[2]);
           
          
            ps.execute();
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null, ex);   
        }
    }
     public void kullaniciEkle()throws SQLException{
        try
        {
            //JOptionPane.showMessageDialog(null, dizi[0]);
            Veritabanıbağlantısı vb=new Veritabanıbağlantısı();
            vb.baglan();  
            //JOptionPane.showMessageDialog(null, "Burdasdın.");
            //ResultSet rs;  //butoon işlemini yaptı
            String sorgu="insert into akilli_ev_sistemi.kullanici(kadi2,sifre2) values (?,?);";
            
            PreparedStatement ps= vb.con.prepareStatement(sorgu);
            
            ps.setString(1,getKullaniciAdi() );
            ps.setString(2,getKullaniciSifre() );
           
            System.out.println("Ekleme Başarılı");
          
            ps.execute();
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null, ex);   
        }
    }
 public ArrayList<veriTabani> veriler() throws SQLException
    {
        Veritabanıbağlantısı vb=new Veritabanıbağlantısı();
        vb.baglan();
        String sorgu="SELECT\n" +
            "val,analogSensor,sicaklik\n" +
            "FROM veriler v where kayit_tarihi like \"2017-05-08 03%\";";
        ArrayList<veriTabani> liste = new ArrayList<veriTabani>();
        
        PreparedStatement ps=vb.con.prepareStatement(sorgu);
        //ps.setInt(1, a);
        ResultSet rs=ps.executeQuery();
        try 
        {        
            while (rs.next()) {
                    veriTabani vt=new veriTabani();
                    vt.setVal(rs.getString("value"));
                    vt.setAnalogSensor(rs.getString("analogSensor"));
                    vt.setSicaklik(rs.getString("sicaklik"));
                    
                 
                    
                    
                    liste.add(vt);                    
                    }
        }
            catch(Exception ex)
            {
                    JOptionPane.showMessageDialog(null, ex);
                    
            }
         return liste;
    }
 public ArrayList tarihGetir() throws SQLException
    {
     
        Veritabanıbağlantısı vb =new Veritabanıbağlantısı();
        vb.baglan();
        String sorgu= "select distinct date_format(kayit_tarihi,'%Y-%m-%d') as tarihler from akilli_ev_sistemi.veriler";
       
        ArrayList<veriTabani> liste2 = new ArrayList<veriTabani>();
       
        PreparedStatement ps=vb.con.prepareStatement(sorgu);
        ResultSet rs=ps.executeQuery();
        try 
        {        
            while (rs.next()) {
                    veriTabani vt=new veriTabani();
                    vt.setTarih(rs.getString("tarihler"));
                    liste2.add(vt);                    
                    }
          
        }
            catch(Exception ex)
            {
                    JOptionPane.showMessageDialog(null, ex);
                    
            }
         return liste2;
    }

    
 }
    
