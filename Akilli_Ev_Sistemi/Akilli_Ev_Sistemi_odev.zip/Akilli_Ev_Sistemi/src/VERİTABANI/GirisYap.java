/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VERİTABANI;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.xml.transform.Result;

/**
 *
 * @author Leyla
 */
public class GirisYap {

   
    public  boolean girisYap2(String alinanAd2, String alinanSifre2) throws SQLException {
        PreparedStatement ps;
        ResultSet rs;
        
        Veritabanıbağlantısı vb = new Veritabanıbağlantısı();
        try {
            vb.baglan();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Veritabanı bağlantısı hatası"+ e);
        }
      
        
        String sql="SELECT sifre2 from kullanici  where kadi2 =?";
        ps = vb.con.prepareStatement(sql);
        ps.setString(1,alinanAd2);
        
        rs=ps.executeQuery();
        String gercekSifre2;
        while (rs.next()) {
             gercekSifre2 = rs.getString("sifre2");
            if(!gercekSifre2.equals(alinanSifre2)){
                return false;
             }
            else{
                return gercekSifre2.equals(alinanSifre2);
             }
   
        }
           return false;
      
    }
}
    

