/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VERİTABANI;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.xml.transform.Result;

/**
 *
 * @author Leyla
 */
public class GirisYap2 {
    public int girisSayisi2=2;
   
    public  boolean girisYap(String alinanAd, String alinanSifre) throws SQLException{
        PreparedStatement ps;
        ResultSet rs;
        
        Veritabanıbağlantısı vb = new Veritabanıbağlantısı();
        try {
            vb.baglan();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Veritabanı bağlantısı hatası"+ e);
        }
      
        
        String sql="SELECT sifre from admin  where kadi =?";
        ps = vb.con.prepareStatement(sql);
        ps.setString(1,alinanAd);
        
        rs=ps.executeQuery();
        String gercekSifre;
        while (rs.next()) {
             gercekSifre = rs.getString("sifre");
            if(!gercekSifre.equals(alinanSifre)){
                return false;
             }
            else{
                return gercekSifre.equals(alinanSifre);
             }
   
        }
           return false;
      
    }
}
    

