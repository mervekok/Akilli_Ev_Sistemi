/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VERİTABANI;

import com.mysql.jdbc.Statement;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Leyla
 */
public class Veritabanıbağlantısı{
    public final String Url="jdbc:mysql://localhost:3306/";
    public final String Db_name="akilli_ev_sistemi";
    public final String id="root";
    public final String ps="toor";
    public final String DRIVER="com.mysql.jdbc.Driver";
    
    public Connection con;
    
    public Statement baglan(){
        try{
            Class.forName(DRIVER).newInstance();
            con = DriverManager.getConnection(Url + Db_name, id, ps);
            
            //JOptionPane.showMessageDialog(null, "Bağlantı Başarılı");
        }
        catch(ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException | HeadlessException e){
        
        JOptionPane.showMessageDialog(null,"Bağlantı Başarısız   !!!\n "+e);
        }
        return null;
    }
   // public static void main(String[] args){
    
    //Veritabanıbağlantısı vb =new Veritabanıbağlantısı();
   // vb.baglan();
    //}
}
